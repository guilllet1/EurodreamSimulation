package com.eurodreamsimulation.model;

public class ResultatRang {
    public int rang;
    public double rapport; // Le gain pour ce rang

    public ResultatRang(int rang, double rapport) {
        this.rang = rang;
        this.rapport = rapport;
    }
}